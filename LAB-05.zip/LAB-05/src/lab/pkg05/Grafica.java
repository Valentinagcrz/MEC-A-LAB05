/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab.pkg05;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Grafica extends JFrame {

    private JTextField yearFilterField;
    private JTextField numberFilterField;
    private JTextField valueFilterField;
    private JTextField descriptionFilterField;
    private JButton filterButton;
    private JFreeChart chart;
    private XYSeriesCollection dataset;

    public Grafica() {
        super("Grafica");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        dataset = createDataset();

        
        chart = createChart(dataset);
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        chartPanel.setBackground(Color.white);
        add(chartPanel);

        
        yearFilterField = new JTextField("Año");
        numberFilterField = new JTextField("Numero");
        valueFilterField = new JTextField("Valor");
        descriptionFilterField = new JTextField("Descripcion");

        
        filterButton = new JButton("Filtros");
        filterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                filterDataset();
            }
        });

        // create filter panel
        JPanel filterPanel = new JPanel(new GridLayout(5, 2));
        filterPanel.add(new JLabel("Año:"));
        filterPanel.add(yearFilterField);
        filterPanel.add(new JLabel("Numero:"));
        filterPanel.add(numberFilterField);
        filterPanel.add(new JLabel("Valor:"));
        filterPanel.add(valueFilterField);
        filterPanel.add(new JLabel("Descripcion:"));
        filterPanel.add(descriptionFilterField);
        filterPanel.add(new JLabel(""));
        filterPanel.add(filterButton);
        filterPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createEtchedBorder(),
                        "Filters"),
                BorderFactory.createEmptyBorder(5,5,5,5)));
        add(filterPanel, "East");

      
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private XYSeriesCollection createDataset() {
        XYSeriesCollection dataset = new XYSeriesCollection();

      
        XYSeries series = new XYSeries("Data");
        series.add(2010, 7);
        series.add(2011, 12);
        series.add(2012, 18);
        series.add(2013, 20);
        series.add(2014, 15);
        dataset.addSeries(series);

        return dataset;
    }

    private JFreeChart createChart(XYDataset dataset) {
        JFreeChart chart = ChartFactory.createXYLineChart(
                "Grafica",
                "Año",
                "Numero",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false);

     
        chart.setBackgroundPaint(Color.white);
        XYPlot plot = chart.getXYPlot();
        plot.setBackgroundPaint(Color.lightGray);
        plot.setDomainGridlinePaint(Color.white);
        plot.setRangeGridlinePaint(Color.white);
        plot.setRangeGridlineStroke(new BasicStroke(1.5f));
        plot.setRangeMinorGridlinePaint(Color.gray);
        plot.setRangeMinorGridlineStroke(new BasicStroke(0.5f));
        plot.setDomainMinorGridlinePaint(Color.gray);
        plot.setDomainMinorGridlineStroke(new BasicStroke(0.5f));

       
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setBaseShapesVisible(true);
        renderer.setBaseShapesFilled(true);
        renderer.setDrawSeriesLineAsPath(true);
        plot.setRenderer(renderer);

        chart.setTitle(new TextTitle("Impuesto predial",
                        new Font("Arial", Font.BOLD, 18)));
        chart.setBorderPaint(Color.black);
        chart.setBorderStroke(new BasicStroke(2));
        chart.setBorderVisible(true);

        
        chart.getLegend().setFrame(BlockBorder.NONE);
        chart.getLegend().setItemFont(new Font("Arial", Font.PLAIN, 12));

        return chart;
    }

    private void filterDataset() {
        List<Integer> years = new ArrayList<Integer>();
        List<Integer> numbers = new ArrayList<Integer>();
        List<Integer> values = new ArrayList<Integer>();
        List<String> descriptions = new ArrayList<String>();


        String yearFilter = yearFilterField.getText().trim();
        String numberFilter = numberFilterField.getText().trim();
        String valueFilter = valueFilterField.getText().trim();
        String descriptionFilter = descriptionFilterField.getText().trim();

        int seriesCount = dataset.getSeriesCount();
        for (int i = 0; i < seriesCount; i++) {
            XYSeries series = dataset.getSeries(i);
            int itemCount = series.getItemCount();
            for (int j = 0; j < itemCount; j++) {
                int x = (int) series.getX(j);
                int y = (int) series.getY(j);
                String description = "Data Point " + i + "-" + j;

            
                if (yearFilter.isEmpty() || yearFilter.equals(String.valueOf(x))) {
                    years.add(x);
                }
                if (numberFilter.isEmpty() || numberFilter.equals(String.valueOf(i))) {
                    numbers.add(i);
                }
                if (valueFilter.isEmpty() || valueFilter.equals(String.valueOf(y))) {
                    values.add(y);
                }
                if (descriptionFilter.isEmpty() || description.contains(descriptionFilter)) {
                    descriptions.add(description);
                }
            }
        }

        
        XYSeriesCollection filteredDataset = new XYSeriesCollection();
        for (int i = 0; i < years.size(); i++) {
            int year = years.get(i);
            int number = numbers.get(i);
            int value = values.get(i);
            String description = descriptions.get(i);

            XYSeries series = new XYSeries(description);
            series.add(year, value);
            filteredDataset.addSeries(series);
        }

       
        XYPlot plot = (XYPlot) chart.getPlot();
        plot.setDataset(filteredDataset);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Grafica();
            }
        });
    }

}